package command_test

import (
	"context"
	"testing"

	"github.com/Cianameo/Apache/app/dispatcher"
	"github.com/Cianameo/Apache/app/log"
	. "github.com/Cianameo/Apache/app/log/command"
	"github.com/Cianameo/Apache/app/proxyman"
	_ "github.com/Cianameo/Apache/app/proxyman/inbound"
	_ "github.com/Cianameo/Apache/app/proxyman/outbound"
	"github.com/Cianameo/Apache/common"
	"github.com/Cianameo/Apache/common/serial"
	"github.com/Cianameo/Apache/core"
)

func TestLoggerRestart(t *testing.T) {
	v, err := core.New(&core.Config{
		App: []*serial.TypedMessage{
			serial.ToTypedMessage(&log.Config{}),
			serial.ToTypedMessage(&dispatcher.Config{}),
			serial.ToTypedMessage(&proxyman.InboundConfig{}),
			serial.ToTypedMessage(&proxyman.OutboundConfig{}),
		},
	})
	common.Must(err)
	common.Must(v.Start())

	server := &LoggerServer{
		V: v,
	}
	common.Must2(server.RestartLogger(context.Background(), &RestartLoggerRequest{}))
}
