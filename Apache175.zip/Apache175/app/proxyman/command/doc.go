package command

//go:generate go run github.com/Cianameo/Apache/common/errors/errorgen
