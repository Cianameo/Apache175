package observatory

//go:generate go run github.com/Cianameo/Apache/common/errors/errorgen
