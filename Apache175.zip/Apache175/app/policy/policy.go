// Package policy is an implementation of policy.Manager feature.
package policy

//go:generate go run github.com/Cianameo/Apache/common/errors/errorgen
