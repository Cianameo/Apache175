package all

import (
	"github.com/Cianameo/Apache/main/commands/all/api"
	"github.com/Cianameo/Apache/main/commands/all/tls"
	"github.com/Cianameo/Apache/main/commands/base"
)

// go:generate go run github.com/Cianameo/Apache/common/errors/errorgen

func init() {
	base.RootCommand.Commands = append(
		base.RootCommand.Commands,
		api.CmdAPI,
		// cmdConvert,
		tls.CmdTLS,
		cmdUUID,
	)
}
