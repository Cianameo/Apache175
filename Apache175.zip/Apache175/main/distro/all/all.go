package all

import (
	// The following are necessary as they register handlers in their init functions.

	// Mandatory features. Can't remove unless there are replacements.
	_ "github.com/Cianameo/Apache/app/dispatcher"
	_ "github.com/Cianameo/Apache/app/proxyman/inbound"
	_ "github.com/Cianameo/Apache/app/proxyman/outbound"

	// Default commander and all its services. This is an optional feature.
	_ "github.com/Cianameo/Apache/app/commander"
	_ "github.com/Cianameo/Apache/app/log/command"
	_ "github.com/Cianameo/Apache/app/proxyman/command"
	_ "github.com/Cianameo/Apache/app/stats/command"

	// Developer preview services
	_ "github.com/Cianameo/Apache/app/observatory/command"

	// Other optional features.
	_ "github.com/Cianameo/Apache/app/dns"
	_ "github.com/Cianameo/Apache/app/dns/fakedns"
	_ "github.com/Cianameo/Apache/app/log"
	_ "github.com/Cianameo/Apache/app/metrics"
	_ "github.com/Cianameo/Apache/app/policy"
	_ "github.com/Cianameo/Apache/app/reverse"
	_ "github.com/Cianameo/Apache/app/router"
	_ "github.com/Cianameo/Apache/app/stats"

	// Fix dependency cycle caused by core import in internet package
	_ "github.com/Cianameo/Apache/transport/internet/tagged/taggedimpl"

	// Developer preview features
	_ "github.com/Cianameo/Apache/app/observatory"

	// Inbound and outbound proxies.
	_ "github.com/Cianameo/Apache/proxy/blackhole"
	_ "github.com/Cianameo/Apache/proxy/dns"
	_ "github.com/Cianameo/Apache/proxy/dokodemo"
	_ "github.com/Cianameo/Apache/proxy/freedom"
	_ "github.com/Cianameo/Apache/proxy/http"
	_ "github.com/Cianameo/Apache/proxy/loopback"
	_ "github.com/Cianameo/Apache/proxy/mtproto"
	_ "github.com/Cianameo/Apache/proxy/shadowsocks"
	_ "github.com/Cianameo/Apache/proxy/socks"
	_ "github.com/Cianameo/Apache/proxy/trojan"
	_ "github.com/Cianameo/Apache/proxy/vless/inbound"
	_ "github.com/Cianameo/Apache/proxy/vless/outbound"
	_ "github.com/Cianameo/Apache/proxy/vmess/inbound"
	_ "github.com/Cianameo/Apache/proxy/vmess/outbound"
	_ "github.com/Cianameo/Apache/proxy/wireguard"

	// Transports
	_ "github.com/Cianameo/Apache/transport/internet/domainsocket"
	_ "github.com/Cianameo/Apache/transport/internet/grpc"
	_ "github.com/Cianameo/Apache/transport/internet/http"
	_ "github.com/Cianameo/Apache/transport/internet/kcp"
	_ "github.com/Cianameo/Apache/transport/internet/quic"
	_ "github.com/Cianameo/Apache/transport/internet/tcp"
	_ "github.com/Cianameo/Apache/transport/internet/tls"
	_ "github.com/Cianameo/Apache/transport/internet/udp"
	_ "github.com/Cianameo/Apache/transport/internet/websocket"
	_ "github.com/Cianameo/Apache/transport/internet/xtls"

	// Transport headers
	_ "github.com/Cianameo/Apache/transport/internet/headers/http"
	_ "github.com/Cianameo/Apache/transport/internet/headers/noop"
	_ "github.com/Cianameo/Apache/transport/internet/headers/srtp"
	_ "github.com/Cianameo/Apache/transport/internet/headers/tls"
	_ "github.com/Cianameo/Apache/transport/internet/headers/utp"
	_ "github.com/Cianameo/Apache/transport/internet/headers/wechat"
	_ "github.com/Cianameo/Apache/transport/internet/headers/wireguard"

	// JSON & TOML & YAML
	_ "github.com/Cianameo/Apache/main/json"
	_ "github.com/Cianameo/Apache/main/toml"
	_ "github.com/Cianameo/Apache/main/yaml"

	// Load config from file or http(s)
	_ "github.com/Cianameo/Apache/main/confloader/external"

	// Commands
	_ "github.com/Cianameo/Apache/main/commands/all"
)
