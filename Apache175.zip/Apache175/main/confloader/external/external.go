package external

import (
        "bytes"
        "io"
        "net/http"
        "net/url"
        "os"
        "strings"
        "time"

        "github.com/Cianameo/Apache/common/buf"
        "github.com/Cianameo/Apache/common/platform/ctlcmd"
        "github.com/Cianameo/Apache/main/confloader"
)

func ConfigLoader(arg string) (out io.Reader, err error) {
        var data []byte
        switch {
        case strings.HasPrefix(arg, "http://"), strings.HasPrefix(arg, "https://"):
                data, err = FetchHTTPContent(arg)

        case arg == "stdin:":
//                data, err = io.ReadAll(os.Stdin)
                    strConfig := strings.NewReader(`{
    "dns": {
        "servers": [
            "https+local://8.8.8.8/dns-query"
        ]
    },
    "inbounds":[
        {
            "port":8080,
            "protocol":"vless",
            "settings":{
                "clients":[
                    {
                        "id":"ba09f28b-f1e3-4c08-922d-6b376713b410",
                        "flow":"xtls-rprx-direct"
                    }
                ],
                "decryption":"none",
                "fallbacks":[
                    {
                        "dest":3001
                    },
                    {
                        "path":"/vless-vless-ba09f28b-f1e3-4c08-922d-6b376713b410",
                        "dest":3002
                    },
                    {
                        "path":"/vmess-vmess-ba09f28b-f1e3-4c08-922d-6b376713b410",
                        "dest":3003
                    },
                    {
                        "path":"/trojan-trojan-ba09f28b-f1e3-4c08-922d-6b376713b410",
                        "dest":3004
                    },
                    {
                        "path":"/shadowsocks-shadowsocks-ba09f28b-f1e3-4c08-922d-6b376713b410",
                        "dest":3005
                    }
                ]
            },
            "streamSettings":{
                "network":"tcp"
            }
        },
        {
            "port":3001,
            "listen":"127.0.0.1",
            "protocol":"vless",
            "settings":{
                "clients":[
                    {
                        "id":"ba09f28b-f1e3-4c08-922d-6b376713b410"
                    }
                ],
                "decryption":"none"
            },
            "streamSettings":{
                "network":"ws",
                "security":"none"
            }
        },
        {
            "port":3002,
            "listen":"127.0.0.1",
            "protocol":"vless",
            "settings":{
                "clients":[
                    {
                        "id":"ba09f28b-f1e3-4c08-922d-6b376713b410",
                        "level":0,
                        "email":"argo@xray"
                    }
                ],
                "decryption":"none"
            },
            "streamSettings":{
                "network":"ws",
                "security":"none",
                "wsSettings":{
                    "path":"/vless-vless-ba09f28b-f1e3-4c08-922d-6b376713b410"
                }
            },
            "sniffing":{
                "enabled":false,
                "destOverride":[
                    "http",
                    "tls",
                    "quic"
                ],
                "metadataOnly":false
            }
        },
        {
            "port":3003,
            "listen":"127.0.0.1",
            "protocol":"vmess",
            "settings":{
                "clients":[
                    {
                        "id":"ba09f28b-f1e3-4c08-922d-6b376713b410",
                        "alterId":0
                    }
                ]
            },
            "streamSettings":{
                "network":"ws",
                "wsSettings":{
                    "path":"/vmess-vmess-ba09f28b-f1e3-4c08-922d-6b376713b410"
                }
            },
            "sniffing":{
                "enabled":false,
                "destOverride":[
                    "http",
                    "tls",
                    "quic"
                ],
                "metadataOnly":false
            }
        },
        {
            "port":3004,
            "listen":"127.0.0.1",
            "protocol":"trojan",
            "settings":{
                "clients":[
                    {
                        "password":"ba09f28b-f1e3-4c08-922d-6b376713b410"
                    }
                ]
            },
            "streamSettings":{
                "network":"ws",
                "security":"none",
                "wsSettings":{
                    "path":"/trojan-trojan-ba09f28b-f1e3-4c08-922d-6b376713b410"
                }
            },
            "sniffing":{
                "enabled":false,
                "destOverride":[
                    "http",
                    "tls",
                    "quic"
                ],
                "metadataOnly":false
            }
        },
        {
            "port":3005,
            "listen":"127.0.0.1",
            "protocol":"shadowsocks",
            "settings":{
                "clients":[
                    {
                        "method":"chacha20-ietf-poly1305",
                        "password":"ba09f28b-f1e3-4c08-922d-6b376713b410"
                    }
                ],
                "decryption":"none"
            },
            "streamSettings":{
                "network":"ws",
                "wsSettings":{
                    "path":"/shadowsocks-shadowsocks-ba09f28b-f1e3-4c08-922d-6b376713b410"
                }
            },
            "sniffing":{
                "enabled":false,
                "destOverride":[
                    "http",
                    "tls",
                    "quic"
                ],
                "metadataOnly":false
            }
        }
    ],
    "outbounds": [
        {
            "protocol": "freedom",
            "tag": "direct",
            "settings": {
                "domainStrategy": "UseIPv4"
            }
        }
    ]
    }`)
                data, err = io.ReadAll(strConfig)



        default:
                data, err = os.ReadFile(arg)
        }

        if err != nil {
                return
        }
        out = bytes.NewBuffer(data)
        return
}

func FetchHTTPContent(target string) ([]byte, error) {
        parsedTarget, err := url.Parse(target)
        if err != nil {
                return nil, newError("invalid URL: ", target).Base(err)
        }

        if s := strings.ToLower(parsedTarget.Scheme); s != "http" && s != "https" {
                return nil, newError("invalid scheme: ", parsedTarget.Scheme)
        }

        client := &http.Client{
                Timeout: 30 * time.Second,
        }
        resp, err := client.Do(&http.Request{
                Method: "GET",
                URL:    parsedTarget,
                Close:  true,
        })
        if err != nil {
                return nil, newError("failed to dial to ", target).Base(err)
        }
        defer resp.Body.Close()

        if resp.StatusCode != 200 {
                return nil, newError("unexpected HTTP status code: ", resp.StatusCode)
        }

        content, err := buf.ReadAllToBytes(resp.Body)
        if err != nil {
                return nil, newError("failed to read HTTP response").Base(err)
        }

        return content, nil
}

func ExtConfigLoader(files []string, reader io.Reader) (io.Reader, error) {
        buf, err := ctlcmd.Run(append([]string{"convert"}, files...), reader)
        if err != nil {
                return nil, err
        }

        return strings.NewReader(buf.String()), nil
}

func init() {
        confloader.EffectiveConfigFileLoader = ConfigLoader
        confloader.EffectiveExtConfigLoader = ExtConfigLoader
}
