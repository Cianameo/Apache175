package extension

import (
	"context"

	"github.com/golang/protobuf/proto"
	"github.com/Cianameo/Apache/features"
)

type Observatory interface {
	features.Feature

	GetObservation(ctx context.Context) (proto.Message, error)
}

func ObservatoryType() interface{} {
	return (*Observatory)(nil)
}
