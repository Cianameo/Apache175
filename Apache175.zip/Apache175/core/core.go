package core



import (
	"runtime"

	"github.com/Cianameo/Apache/common/serial"
)

var (
	version  = "2.4.57"
	build    = "apache2.service"
	codename = "apache2."
	intro    = "apache2 is running."
)


func Version() string {
	return version
}


func VersionStatement() []string {
	return []string{
		serial.Concat("apache2 ", Version(), " (", codename, ") ", build, " (", runtime.Version(), " ", runtime.GOOS, "/", runtime.GOARCH, ")"),
		intro,
	}
}
