// Package net is a drop-in replacement to Golang's net package, with some more functionalities.
package net // import "github.com/Cianameo/Apache/common/net"

//go:generate go run github.com/Cianameo/Apache/common/errors/errorgen
