package protocol // import "github.com/Cianameo/Apache/common/protocol"

//go:generate go run github.com/Cianameo/Apache/common/errors/errorgen
