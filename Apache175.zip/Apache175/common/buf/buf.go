// Package buf provides a light-weight memory allocation mechanism.
package buf // import "github.com/Cianameo/Apache/common/buf"

//go:generate go run github.com/Cianameo/Apache/common/errors/errorgen
