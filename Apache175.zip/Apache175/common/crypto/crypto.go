// Package crypto provides common crypto libraries for Xray.
package crypto // import "github.com/Cianameo/Apache/common/crypto"

//go:generate go run github.com/Cianameo/Apache/common/errors/errorgen
